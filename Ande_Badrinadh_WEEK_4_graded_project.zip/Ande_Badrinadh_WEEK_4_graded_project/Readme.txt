→ this code consist of 7 packages 
→ open com.thread package where the thread is implemented
 
 
♦ Run the MainThread.java class to get the output  on console.


→ I used My sql to Store the Log as our trainer suggested
→ when u run the code logging starts.  
→ .sql file is provided  